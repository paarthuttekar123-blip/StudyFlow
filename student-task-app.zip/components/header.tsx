"use client"

import { format } from "date-fns"
import { BookOpen, Sparkles } from "lucide-react"

export function Header() {
  const today = new Date()
  const greeting = getGreeting()

  return (
    <header className="flex flex-col gap-1 pb-6">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary text-primary-foreground">
          <BookOpen className="w-5 h-5" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight" style={{ fontFamily: "var(--font-heading)" }}>
          StudyFlow
        </h1>
      </div>
      <div className="flex items-center justify-between mt-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
              {greeting}
            </h2>
            <Sparkles className="w-5 h-5 text-chart-5" />
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {format(today, "EEEE, MMMM d, yyyy")}
          </p>
        </div>
      </div>
    </header>
  )
}

function getGreeting(): string {
  const hour = new Date().getHours()
  if (hour < 12) return "Good Morning"
  if (hour < 17) return "Good Afternoon"
  return "Good Evening"
}
