"use client"

import { useState } from "react"
import { Plus, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { CATEGORY_CONFIG, PRIORITY_CONFIG, type TaskCategory, type TaskPriority } from "@/lib/task-store"

interface AddTaskFormProps {
  onAdd: (title: string, category: TaskCategory, priority: TaskPriority, dueTime?: string) => void
}

export function AddTaskForm({ onAdd }: AddTaskFormProps) {
  const [title, setTitle] = useState("")
  const [category, setCategory] = useState<TaskCategory>("python")
  const [priority, setPriority] = useState<TaskPriority>("learning-study")
  const [dueTime, setDueTime] = useState("")
  const [isExpanded, setIsExpanded] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!title.trim()) return
    onAdd(title.trim(), category, priority, dueTime || undefined)
    setTitle("")
    setCategory("python")
    setPriority("learning-study")
    setDueTime("")
    setIsExpanded(false)
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-2xl bg-card border border-border shadow-sm overflow-hidden">
      <div className="flex items-center gap-3 p-4">
        <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-primary/10 text-primary flex-shrink-0">
          <Plus className="w-5 h-5" />
        </div>
        <Input
          type="text"
          placeholder="Add a new task..."
          value={title}
          onChange={(e) => {
            setTitle(e.target.value)
            if (!isExpanded && e.target.value) setIsExpanded(true)
          }}
          onFocus={() => setIsExpanded(true)}
          className="border-0 bg-transparent text-base placeholder:text-muted-foreground/60 focus-visible:ring-0 focus-visible:ring-offset-0 px-0 h-auto"
        />
      </div>

      {isExpanded && (
        <div className="px-4 pb-4 pt-0 flex flex-col gap-3 animate-in slide-in-from-top-2 fade-in duration-200">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={category} onValueChange={(v) => setCategory(v as TaskCategory)}>
              <SelectTrigger className="w-[220px] h-9 text-sm rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(CATEGORY_CONFIG).map(([key, config]) => (
                  <SelectItem key={key} value={key}>
                    <span className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-md flex items-center justify-center text-xs font-bold ${config.bg} ${config.color}`}>
                        {config.emoji}
                      </span>
                      {config.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={priority} onValueChange={(v) => setPriority(v as TaskPriority)}>
              <SelectTrigger className="w-[130px] h-9 text-sm rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(PRIORITY_CONFIG).map(([key, config]) => (
                  <SelectItem key={key} value={key}>
                    <span className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${config.dot}`} />
                      {config.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex items-center gap-1.5 bg-secondary rounded-lg px-3 h-9">
              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
              <input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="bg-transparent text-sm text-foreground outline-none w-[90px]"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setIsExpanded(false)
                setTitle("")
              }}
              className="text-muted-foreground"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              disabled={!title.trim()}
              className="rounded-lg bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Task
            </Button>
          </div>
        </div>
      )}
    </form>
  )
}
