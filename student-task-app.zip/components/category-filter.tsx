"use client"

import { CATEGORY_CONFIG, type TaskCategory, type Task } from "@/lib/task-store"
import { cn } from "@/lib/utils"
import { LayoutGrid } from "lucide-react"

interface CategoryFilterProps {
  tasks: Task[]
  active: TaskCategory | "all"
  onChange: (category: TaskCategory | "all") => void
}

export function CategoryFilter({ tasks, active, onChange }: CategoryFilterProps) {
  const allCount = tasks.length
  const categoryCounts = Object.keys(CATEGORY_CONFIG).reduce((acc, key) => {
    acc[key as TaskCategory] = tasks.filter((t) => t.category === key).length
    return acc
  }, {} as Record<TaskCategory, number>)

  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
      <button
        onClick={() => onChange("all")}
        className={cn(
          "flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200",
          active === "all"
            ? "bg-primary text-primary-foreground shadow-sm"
            : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
        )}
      >
        <LayoutGrid className="w-3.5 h-3.5" />
        All
        <span className={cn(
          "ml-0.5 px-1.5 py-0.5 rounded-md text-xs font-semibold",
          active === "all" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"
        )}>
          {allCount}
        </span>
      </button>

      {Object.entries(CATEGORY_CONFIG).map(([key, config]) => {
        const count = categoryCounts[key as TaskCategory]
        if (count === 0) return null
        return (
          <button
            key={key}
            onClick={() => onChange(key as TaskCategory)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200",
              active === key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
            )}
          >
            <span className={cn(
              "w-5 h-5 rounded-md flex items-center justify-center text-xs font-bold",
              active === key ? "bg-primary-foreground/20 text-primary-foreground" : `${config.bg} ${config.color}`
            )}>
              {config.emoji}
            </span>
            {config.label}
            <span className={cn(
              "ml-0.5 px-1.5 py-0.5 rounded-md text-xs font-semibold",
              active === key ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"
            )}>
              {count}
            </span>
          </button>
        )
      })}
    </div>
  )
}
