"use client"

import { useState } from "react"
import { Check, Clock, Trash2 } from "lucide-react"
import { CATEGORY_CONFIG, PRIORITY_CONFIG, type Task } from "@/lib/task-store"
import { cn } from "@/lib/utils"

interface TaskCardProps {
  task: Task
  onToggle: (id: string) => void
  onDelete: (id: string) => void
}

export function TaskCard({ task, onToggle, onDelete }: TaskCardProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const category = CATEGORY_CONFIG[task.category]
  const priority = PRIORITY_CONFIG[task.priority]

  function handleDelete() {
    setIsDeleting(true)
    setTimeout(() => onDelete(task.id), 300)
  }

  return (
    <div
      className={cn(
        "group relative flex items-center gap-3 p-4 rounded-xl bg-card border border-border transition-all duration-300",
        "hover:shadow-md hover:border-primary/20",
        task.completed && "opacity-60",
        isDeleting && "opacity-0 scale-95 -translate-x-4"
      )}
    >
      {/* Priority indicator */}
      <div className={`absolute left-0 top-3 bottom-3 w-1 rounded-r-full ${priority.dot} transition-opacity ${task.completed ? "opacity-30" : "opacity-100"}`} />

      {/* Checkbox */}
      <button
        onClick={() => onToggle(task.id)}
        className={cn(
          "flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ml-2",
          task.completed
            ? "bg-success border-success text-success-foreground"
            : "border-border hover:border-primary hover:bg-primary/5"
        )}
        aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
      >
        {task.completed && <Check className="w-3.5 h-3.5" />}
      </button>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "text-sm font-medium transition-all duration-200 truncate",
              task.completed ? "line-through text-muted-foreground" : "text-foreground"
            )}
          >
            {task.title}
          </span>
        </div>
        <div className="flex items-center gap-2 mt-1.5">
          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium ${category.bg} ${category.color}`}>
            <span className="font-bold">{category.emoji}</span>
            {category.label}
          </span>
          {task.dueTime && (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              {task.dueTime}
            </span>
          )}
        </div>
      </div>

      {/* Delete */}
      <button
        onClick={handleDelete}
        className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all duration-200"
        aria-label="Delete task"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  )
}
