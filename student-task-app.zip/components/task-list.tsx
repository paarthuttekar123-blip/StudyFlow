"use client"

import { useMemo } from "react"
import { ClipboardList } from "lucide-react"
import { TaskCard } from "@/components/task-card"
import type { Task, TaskCategory } from "@/lib/task-store"

interface TaskListProps {
  tasks: Task[]
  filter: TaskCategory | "all"
  onToggle: (id: string) => void
  onDelete: (id: string) => void
}

export function TaskList({ tasks, filter, onToggle, onDelete }: TaskListProps) {
  const filteredTasks = useMemo(() => {
    const filtered = filter === "all" ? tasks : tasks.filter((t) => t.category === filter)
    return [...filtered].sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1
      const priorityOrder: Record<string, number> = { skill: 0, practical: 1, "learning-study": 2 }
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    })
  }, [tasks, filter])

  if (filteredTasks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center">
          <ClipboardList className="w-8 h-8 text-muted-foreground" />
        </div>
        <p className="text-base font-medium text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
          No tasks yet
        </p>
        <p className="text-sm text-muted-foreground text-center max-w-xs">
          Add your first task above to start organizing your day
        </p>
      </div>
    )
  }

  const pendingTasks = filteredTasks.filter((t) => !t.completed)
  const completedTasks = filteredTasks.filter((t) => t.completed)

  return (
    <div className="flex flex-col gap-6">
      {pendingTasks.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">
            Pending ({pendingTasks.length})
          </h3>
          <div className="flex flex-col gap-2">
            {pendingTasks.map((task) => (
              <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
            ))}
          </div>
        </div>
      )}
      {completedTasks.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">
            Completed ({completedTasks.length})
          </h3>
          <div className="flex flex-col gap-2">
            {completedTasks.map((task) => (
              <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
