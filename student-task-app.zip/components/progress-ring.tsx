"use client"

import { useMemo } from "react"
import { Trophy, Flame, Target } from "lucide-react"

interface ProgressRingProps {
  total: number
  completed: number
}

export function ProgressRing({ total, completed }: ProgressRingProps) {
  const percentage = total === 0 ? 0 : Math.round((completed / total) * 100)

  const circumference = 2 * Math.PI * 54
  const strokeDashoffset = circumference - (percentage / 100) * circumference

  const status = useMemo(() => {
    if (total === 0) return { icon: Target, label: "Add your first task!", color: "text-muted-foreground" }
    if (percentage === 100) return { icon: Trophy, label: "All done! Amazing!", color: "text-success" }
    if (percentage >= 50) return { icon: Flame, label: "Keep going!", color: "text-chart-3" }
    return { icon: Target, label: "Let's get started!", color: "text-primary" }
  }, [total, percentage])

  const StatusIcon = status.icon

  return (
    <div className="flex items-center gap-6 p-5 rounded-2xl bg-card border border-border shadow-sm">
      <div className="relative flex-shrink-0">
        <svg className="w-28 h-28 -rotate-90" viewBox="0 0 120 120">
          <circle
            cx="60"
            cy="60"
            r="54"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            className="text-muted"
          />
          <circle
            cx="60"
            cy="60"
            r="54"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeLinecap="round"
            className="text-primary transition-all duration-700 ease-out"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
            {percentage}%
          </span>
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-2">
          <StatusIcon className={`w-5 h-5 ${status.color}`} />
          <span className="text-sm font-medium text-foreground">{status.label}</span>
        </div>
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">{completed}</span> of{" "}
          <span className="font-semibold text-foreground">{total}</span> tasks completed
        </p>
        <div className="flex gap-1.5 mt-1">
          {Array.from({ length: Math.min(total, 10) }).map((_, i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                i < completed ? "bg-primary scale-100" : "bg-muted scale-90"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
