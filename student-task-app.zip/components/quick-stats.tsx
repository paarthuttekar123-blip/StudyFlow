"use client"

import { ListTodo, CheckCircle2, AlertTriangle, Clock } from "lucide-react"
import type { Task } from "@/lib/task-store"

interface QuickStatsProps {
  tasks: Task[]
}

export function QuickStats({ tasks }: QuickStatsProps) {
  const total = tasks.length
  const completed = tasks.filter((t) => t.completed).length
  const skillTasks = tasks.filter((t) => t.priority === "skill" && !t.completed).length
  const withDueTime = tasks.filter((t) => t.dueTime && !t.completed).length

  const stats = [
    {
      icon: ListTodo,
      label: "Total",
      value: total,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      icon: CheckCircle2,
      label: "Done",
      value: completed,
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      icon: AlertTriangle,
      label: "Skill",
      value: skillTasks,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      icon: Clock,
      label: "Scheduled",
      value: withDueTime,
      color: "text-chart-3",
      bg: "bg-chart-3/10",
    },
  ]

  return (
    <div className="grid grid-cols-4 gap-2">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border"
        >
          <div className={`w-8 h-8 rounded-lg ${stat.bg} flex items-center justify-center`}>
            <stat.icon className={`w-4 h-4 ${stat.color}`} />
          </div>
          <span className="text-lg font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
            {stat.value}
          </span>
          <span className="text-xs text-muted-foreground">{stat.label}</span>
        </div>
      ))}
    </div>
  )
}
