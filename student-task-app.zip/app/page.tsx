"use client"

import { useState, useCallback, useEffect } from "react"
import { toast } from "sonner"
import { Header } from "@/components/header"
import { ProgressRing } from "@/components/progress-ring"
import { AddTaskForm } from "@/components/add-task-form"
import { CategoryFilter } from "@/components/category-filter"
import { TaskList } from "@/components/task-list"
import { QuickStats } from "@/components/quick-stats"
import {
  loadTasks,
  saveTasks,
  createTask,
  type Task,
  type TaskCategory,
  type TaskPriority,
} from "@/lib/task-store"

export default function Home() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [filter, setFilter] = useState<TaskCategory | "all">("all")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setTasks(loadTasks())
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted) saveTasks(tasks)
  }, [tasks, mounted])

  const handleAdd = useCallback(
    (title: string, category: TaskCategory, priority: TaskPriority, dueTime?: string) => {
      const newTask = createTask(title, category, priority, dueTime)
      setTasks((prev) => [newTask, ...prev])
      toast.success("Task added!", { description: title })
    },
    []
  )

  const handleToggle = useCallback((id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t
        const toggled = { ...t, completed: !t.completed }
        if (toggled.completed) {
          toast.success("Nice work!", { description: `"${t.title}" completed` })
        }
        return toggled
      })
    )
  }, [])

  const handleDelete = useCallback((id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id))
    toast("Task removed")
  }, [])

  const completedCount = tasks.filter((t) => t.completed).length

  if (!mounted) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Decorative background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute top-1/3 -left-40 w-96 h-96 rounded-full bg-accent/5 blur-3xl" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-8 pb-24">
        <Header />

        <div className="flex flex-col gap-5">
          {/* Progress */}
          <ProgressRing total={tasks.length} completed={completedCount} />

          {/* Quick Stats */}
          <QuickStats tasks={tasks} />

          {/* Add Task */}
          <AddTaskForm onAdd={handleAdd} />

          {/* Filters */}
          {tasks.length > 0 && (
            <CategoryFilter tasks={tasks} active={filter} onChange={setFilter} />
          )}

          {/* Task List */}
          <TaskList
            tasks={tasks}
            filter={filter}
            onToggle={handleToggle}
            onDelete={handleDelete}
          />
        </div>
      </div>
    </main>
  )
}
