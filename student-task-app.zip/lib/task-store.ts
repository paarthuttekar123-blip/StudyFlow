export type TaskCategory = "business-fundamentals" | "python" | "fundamentals-of-ml" | "os" | "applied-math-2" | "data-structure"
export type TaskPriority = "skill" | "practical" | "learning-study"

export interface Task {
  id: string
  title: string
  category: TaskCategory
  priority: TaskPriority
  completed: boolean
  createdAt: string
  dueTime?: string
}

export const CATEGORY_CONFIG: Record<TaskCategory, { label: string; emoji: string; color: string; bg: string }> = {
  "business-fundamentals": { label: "Business Fundamentals", emoji: "BF", color: "text-primary", bg: "bg-primary/10" },
  "python": { label: "Python", emoji: "PY", color: "text-success", bg: "bg-success/10" },
  "fundamentals-of-ml": { label: "Fundamentals of ML", emoji: "ML", color: "text-chart-3", bg: "bg-chart-3/10" },
  "os": { label: "OS", emoji: "OS", color: "text-chart-4", bg: "bg-chart-4/10" },
  "applied-math-2": { label: "Applied Mathematics-2", emoji: "AM", color: "text-chart-5", bg: "bg-chart-5/10" },
  "data-structure": { label: "Data Structure", emoji: "DS", color: "text-chart-1", bg: "bg-chart-1/10" },
}

export const PRIORITY_CONFIG: Record<TaskPriority, { label: string; color: string; dot: string }> = {
  skill: { label: "Skill", color: "text-primary", dot: "bg-primary" },
  practical: { label: "Practical", color: "text-chart-3", dot: "bg-chart-3" },
  "learning-study": { label: "Learning/Study", color: "text-success", dot: "bg-success" },
}

const STORAGE_KEY = "studyflow-tasks"

export function loadTasks(): Task[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (!stored) return []
    return JSON.parse(stored)
  } catch {
    return []
  }
}

export function saveTasks(tasks: Task[]) {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks))
}

export function createTask(
  title: string,
  category: TaskCategory,
  priority: TaskPriority,
  dueTime?: string
): Task {
  return {
    id: crypto.randomUUID(),
    title,
    category,
    priority,
    completed: false,
    createdAt: new Date().toISOString(),
    dueTime,
  }
}
